package com.example.tosunclient;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

import java.util.Comparator;

public class ElytraTarget {

    private static final double RANGE = 64.0;
    private static final float TURN_SPEED = 0.25f;
    private static int fireworkCooldown = 0;

    public static void tick(MinecraftClient mc) {
        if (!TosunClient.ELYTRA_TARGET.enabled) return;

        ClientPlayerEntity player = mc.player;
        if (player == null || mc.world == null || mc.interactionManager == null) return;

        // Sadece singleplayer: sunucularda çalışmaz
        if (!mc.isInSingleplayer()) return;

        // Sadece elytra ile uçarken çalışır
        if (!player.isGliding()) return;

        // En yakın canlıyı bul (kendin hariç)
        LivingEntity target = mc.world.getEntitiesByClass(
                        LivingEntity.class,
                        player.getBoundingBox().expand(RANGE),
                        e -> e != player && e.isAlive())
                .stream()
                .min(Comparator.comparingDouble(e -> player.squaredDistanceTo(e)))
                .orElse(null);
        if (target == null) return;

        // Hedefin biraz ilerisini nişan al (hareket tahmini)
        Vec3d aim = target.getEyePos().add(target.getVelocity().multiply(2));
        Vec3d diff = aim.subtract(player.getEyePos());
        double flat = Math.sqrt(diff.x * diff.x + diff.z * diff.z);

        float yaw = (float) (Math.toDegrees(Math.atan2(diff.z, diff.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(diff.y, flat));

        // Yumuşak dönüş (anında kilitlenmez)
        player.setYaw(MathHelper.lerpAngleDegrees(TURN_SPEED, player.getYaw(), yaw));
        player.setPitch(MathHelper.lerp(TURN_SPEED, player.getPitch(), MathHelper.clamp(pitch, -90f, 90f)));

        // Elindeki havai fişeği yavaşlayınca kullan
        if (fireworkCooldown > 0) fireworkCooldown--;
        if (fireworkCooldown == 0
                && player.getVelocity().length() < 1.0
                && player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)) {
            mc.interactionManager.interactItem(player, Hand.MAIN_HAND);
            fireworkCooldown = 30;
        }
    }
}
