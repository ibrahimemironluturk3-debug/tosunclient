package com.example.tosunclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class TosunClient implements ClientModInitializer {

    public static class Module {
        public final String name;
        public boolean enabled = true;

        Module(String name) {
            this(name, true);
        }

        Module(String name, boolean enabled) {
            this.name = name;
            this.enabled = enabled;
        }
    }

    public static final Module FPS = new Module("FPS");
    public static final Module COORDS = new Module("Koordinat");
    public static final Module KEYS = new Module("Tuşlar (WASD)");
    public static final Module ELYTRA_TARGET = new Module("ElytraTarget", false);
    public static final List<Module> MODULES = List.of(FPS, COORDS, KEYS, ELYTRA_TARGET);

    private static KeyBinding menuKey;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.tosunclient.menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.create(Identifier.of("tosunclient", "main"))
        ));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            ElytraTarget.tick(mc);
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) {
                    mc.setScreen(new ClickGuiScreen());
                }
            }
        });

        HudElementRegistry.attachElementAfter(
                VanillaHudElements.MISC_OVERLAYS,
                Identifier.of("tosunclient", "hud"),
                this::renderHud
        );
    }

    private void renderHud(DrawContext ctx, RenderTickCounter tickCounter) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;

        int y = 5;
        ctx.drawTextWithShadow(mc.textRenderer, "TosunClient", 5, y, 0xFF55FFFF);
        y += 12;

        if (FPS.enabled) {
            ctx.drawTextWithShadow(mc.textRenderer, "FPS: " + mc.getCurrentFps(), 5, y, 0xFFFFFFFF);
            y += 11;
        }

        if (COORDS.enabled) {
            String xyz = "XYZ: " + (int) mc.player.getX()
                    + " " + (int) mc.player.getY()
                    + " " + (int) mc.player.getZ();
            ctx.drawTextWithShadow(mc.textRenderer, xyz, 5, y, 0xFFFFFFFF);
            y += 11;
        }

        if (KEYS.enabled) {
            String keys = (mc.options.forwardKey.isPressed() ? "W" : "-")
                    + (mc.options.leftKey.isPressed() ? "A" : "-")
                    + (mc.options.backKey.isPressed() ? "S" : "-")
                    + (mc.options.rightKey.isPressed() ? "D" : "-");
            ctx.drawTextWithShadow(mc.textRenderer, keys, 5, y, 0xFFFFFF55);
        }
    }
}
