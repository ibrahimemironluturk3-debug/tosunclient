package com.example.tosunclient;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

public class ClickGuiScreen extends Screen {

    public ClickGuiScreen() {
        super(Text.literal("TosunClient"));
    }

    @Override
    protected void init() {
        int w = 150, h = 20;
        int x = width / 2 - w / 2;
        int y = height / 2 - 30;

        for (TosunClient.Module m : TosunClient.MODULES) {
            addDrawableChild(ButtonWidget.builder(label(m), btn -> {
                m.enabled = !m.enabled;
                btn.setMessage(label(m));
            }).dimensions(x, y, w, h).build());
            y += h + 4;
        }
    }

    private Text label(TosunClient.Module m) {
        return Text.literal(m.name + ": " + (m.enabled ? "AÇIK" : "KAPALI"))
                .formatted(m.enabled ? Formatting.GREEN : Formatting.RED);
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "TosunClient", width / 2, height / 2 - 55, 0xFF55FFFF);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
